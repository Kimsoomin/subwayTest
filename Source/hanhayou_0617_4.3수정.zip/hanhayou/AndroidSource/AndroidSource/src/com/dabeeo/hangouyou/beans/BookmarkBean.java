package com.dabeeo.hangouyou.beans;

public class BookmarkBean
{
  public String title;
  public String category;
  public int likeCount = 0;
  public int reviewCount = 0;
}
