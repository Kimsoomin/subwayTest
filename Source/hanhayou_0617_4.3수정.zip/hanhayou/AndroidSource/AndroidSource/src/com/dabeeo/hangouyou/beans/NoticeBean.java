package com.dabeeo.hangouyou.beans;

public class NoticeBean
{
  public String title;
  public String content;
  
}
