package com.dabeeo.hangouyou.beans;

public class LocalPhotoBean
{
  public boolean isCamera = false;
  public String path;
  public boolean isSelected = false;
  public int selectIndex = -1;
}
