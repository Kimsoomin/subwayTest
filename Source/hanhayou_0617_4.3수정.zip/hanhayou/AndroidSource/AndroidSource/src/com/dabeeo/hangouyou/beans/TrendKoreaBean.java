package com.dabeeo.hangouyou.beans;

public class TrendKoreaBean
{
  public String title;
  public String imageUrl;
  public String category;
}
