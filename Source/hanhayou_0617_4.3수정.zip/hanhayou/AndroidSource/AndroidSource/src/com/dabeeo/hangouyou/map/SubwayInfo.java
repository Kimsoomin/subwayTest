package com.dabeeo.hangouyou.map;

public class SubwayInfo 
{
	public String idx;
	public String line;
	public String name_ko;
	public String name_en;
	public String name_cn;
	public int category;
	public float lat;
	public float lng;
}
