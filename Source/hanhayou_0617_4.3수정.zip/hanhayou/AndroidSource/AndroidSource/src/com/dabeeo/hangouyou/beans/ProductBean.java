package com.dabeeo.hangouyou.beans;

public class ProductBean
{
  public String title;
  public String imageUrl;
  public int originalPrice;
  public int discountPrice;
  public int discountPriceCn;
  public int discountMonth;
}
