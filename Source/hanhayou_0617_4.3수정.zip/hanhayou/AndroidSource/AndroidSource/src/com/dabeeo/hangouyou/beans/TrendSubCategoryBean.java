package com.dabeeo.hangouyou.beans;

public class TrendSubCategoryBean
{
  public String title;
}
