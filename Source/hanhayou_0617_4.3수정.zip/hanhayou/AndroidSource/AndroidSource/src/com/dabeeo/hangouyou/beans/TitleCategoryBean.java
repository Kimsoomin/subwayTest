package com.dabeeo.hangouyou.beans;

public class TitleCategoryBean
{
  public String title;
  public int categoryId;
  
  
  public TitleCategoryBean(String title, int categoryId)
  {
    this.title = title;
    this.categoryId = categoryId;
  }
}
